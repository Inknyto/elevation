// credentials.js
module.exports = {
  username: 'nyto',
  password: 'schoolsucks',
};
